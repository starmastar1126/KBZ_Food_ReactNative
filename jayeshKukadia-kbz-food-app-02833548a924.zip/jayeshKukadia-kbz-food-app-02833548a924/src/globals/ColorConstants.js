module.exports = {
        APP_TINT_COLORS: "#7C7BAD",
        APP_TINT_COLORS_DARK: "#5a5a7e",
        HEADER_TINT_COLOR: "#FFF",
        APP_BACKGROUND_COLOR: "#FFF",
        ICON_COLOR: "#243747",
        TEXT_COLOR: "#333",
        TEXT_INPUT_COLOR: "#181818",
        THUMB_IMAGE_COLOR: '#f5f5f5',
        LINE_COLOR: "#E1E1E1",
        ICON_EMPTY_COLOR: "#A4A4A4",

        LOGIN_BG:"#9D5D2F"
}
