export var isInternetConnected = false
export var odoo;