
module.exports = {
        IOS_DEFAULT_PADDING_TOP : 20,
}
